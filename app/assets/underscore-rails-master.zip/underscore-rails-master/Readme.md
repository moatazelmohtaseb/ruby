Rails 3.1 asset-pipeline gem to provide underscore.js

# Setup

Have in your Gemfile:

	gem 'underscore-rails'

And, have in your application.js manifest:

	//= require underscore

(also directly available under `/assets/underscore.js`)

Easy as pie.
