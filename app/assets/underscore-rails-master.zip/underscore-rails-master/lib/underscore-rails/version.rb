module Underscore
  module Rails
    VERSION = "1.8.2"
  end
end
